from django.apps import AppConfig


class PresupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'presup'
