
function openPrecioModal(){
    var modal = document.querySelector(".edit_precio_modal");
    modal.style.display = "flex";
  
  }
  
function closePrecioModal(){
    var modal = document.querySelector(".edit_precio_modal");
    modal.style.display = "none";
  
  }
  